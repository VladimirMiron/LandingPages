$(document).ready(function() {

	//E-mail Ajax Send
	$("form").submit(function() { //Change
		var th = $(this);
		$.ajax({
			type: "POST",
			url: "./php/call.php", //Change
			data: th.serialize()
		}).done(function() {
			alert("Спасибо мы скоро с вами свяжемся");
			setTimeout(function() {
				// Done Functions
				th.trigger("reset");
			}, 1000);
		});
		return false;
	});

});